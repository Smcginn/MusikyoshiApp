//
//  SSLyric.h
//  SeeScoreLib
//
//  Copyright (c) 2016 Dolphin Computing Ltd. All rights reserved.
//
// No warranty is made as to the suitability of this for any purpose
//

/*!
 @header SSLyric.h
 @abstract a lyric text item in the score attached to a note
 */

#import <Foundation/Foundation.h>

#include "sscore_contents.h"

/*!
 @interface SSLyric
 @abstract a lyric text item in the score attached to a note
 */
@interface SSLyric : NSObject

@property (readonly) NSString *text;

@property (readonly) float fontSize;
@property (readonly) bool bold;
@property (readonly) bool italic;
@property (readonly) enum sscore_lyric_syllabic syllabic;

@property (readonly) const sscore_con_lyric *rawlyric;

//private
-(instancetype)initWithLyric:(sscore_con_lyric*)lyr;
@end
