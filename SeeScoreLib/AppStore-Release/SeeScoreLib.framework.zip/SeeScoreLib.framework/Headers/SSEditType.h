//
//  SSEditType.h
//  SeeScoreLib
//
//  Created by James Sutton on 02/03/2017.
//  Copyright © 2017 Dolphin Computing Ltd. All rights reserved.
//

#ifndef SSEditType_h
#define SSEditType_h

/*!
 @header SSEditType.h
 @abstract wrapper for sscore_edit_type
 */

#import <Foundation/Foundation.h>

#include "sscore_edit.h"

/*!
 @interface SSLyric
 @abstract a lyric text item in the score attached to a note
 */
@interface SSEditType : NSObject

@property (readonly) bool isValid;

@property (readonly) bool isMultiple;

@property (readonly) enum sscore_edit_baseType baseType;

@property (readonly) unsigned subType;

@property (readonly) int intParam0;

@property (readonly) int intParam1;

@property (readonly) NSString *stringParam;

-(instancetype)initWith:(sscore_edit_type*)tp;

@end

#endif /* SSEditType_h */
