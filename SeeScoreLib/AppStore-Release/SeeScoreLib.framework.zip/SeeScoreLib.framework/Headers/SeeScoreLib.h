//
//  SeeScoreLib.h
//  SeeScoreLib
//
//  Copyright (c) 2015 Dolphin Computing Ltd. All rights reserved.
//
// No warranty is made as to the suitability of this for any purpose
//

/*!
 @header	SeeScoreLib.h
 @abstract	The interface to SeeScoreLib
*/

#import "SSScore.h"
#import "SSSystem.h"
#import "SSSynth.h"
#import "SSPData.h"
#import "SSEventHandler.h"
#import "SSPDSyncTiming.h"
#import "SSComponent.h"
#import "SSDisplayedItem.h"
#import "SSEditItem.h"
#import "SSDirectionType.h"
#import "SSTargetLocation.h"
#import "SSLyric.h"
#import "SSEditType.h"

#include "sscore_graphics.h"
#include "sscore_graphics_mac+ios.h"
#include "sscore.h"
#include "sscore_contents.h"
#include "sscore_transpose.h"
#include "sscore_drawopt.h"
#include "sscore_playdata.h"
#include "sscore_synth.h"
#include "sscore_edit.h"
#include "sscore_sym.h"
